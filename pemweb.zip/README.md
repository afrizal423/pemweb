<p align="center">
<a href="https://php.net"><img src="https://img.shields.io/badge/PHP-v7.3.6-blue" alt="PHP"></a>
<a href="https://www.postgresql.org/"><img src="https://img.shields.io/badge/Postgresql-v11.3-lightgreen" alt="DB"></a>
<a href="https://afrizalmy.com"><img src="https://img.shields.io/badge/project%20created%20by-afrizal-lightgrey" alt="Afrizal M"></a>
</p>

## Sistem informasi Peminjaman buku perpustakaan
Project ini adalah project untuk menyelesaikan tugas mata kuliah pemrogaman web. 
